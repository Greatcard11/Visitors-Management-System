# Smart VMS modules package
